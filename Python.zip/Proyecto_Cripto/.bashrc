# Autostart para Grid_Master v9.x  en segundo plano
if ! pgrep -x "python" > /dev/null; then
    echo "⚠️ Iniciando servicios de trading en segundo plano..."
    termux-wake-lock
    # nohup ejecuta el script de forma persistente
    # > /dev/null manda los mensajes a la basura para no ensuciar la consola
    # & lo manda al fondo (background)
    
    nohup sh ~/boot_bot_v9.3.sh >> "/data/data/com.termux/files/home/storage/shared/documents/Job_2025/Python/Proyecto_Cripto/Logs/log_boot.txt" 2>&1 &

    echo "✅ Bot lanzado. Usa 'tail -f log_boot.txt' para ver el progreso."
fi

